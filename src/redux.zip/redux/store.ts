// store.ts
import { configureStore } from "@reduxjs/toolkit";
import productsSlice from "./products/productSlice";
import userSlice from "./users/userSlice";

const rootReducer = {
  products: productsSlice,
  users: userSlice,
};

const store = configureStore({
  reducer: rootReducer,
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export default store;
