import { GET } from "@/app/api/users/route";
import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import { UserTypes } from "@/app/common/FormData";

interface User {
  _id: number;
  name: string;
  username: string;
  email: string;
  phone: number;
  designation: string;
  jobType: string;
  salary: Number;
}

const HOST_NAME = process.env.HOST_NAME || "http://localhost:3000";

const initialState: User[] = [];

export const fetchUsers = createAsyncThunk<User[], void>(
  "users/fetchUsers",
  async () => {
    try {
      const res = await fetch(`${HOST_NAME}/api/users`);
      console.log(res);
      if (!res.ok) {
        throw new Error("Failed to fetch users");
      }
      const jsonData = await res.json();
      return jsonData.data;
    } catch (error) {
      console.error("Error fetching users:", error);
      throw error;
    }
  }
);

export const addUserAsync = createAsyncThunk<User, User>(
  "users/addUserAsync",
  async (newUser) => {
    const response = await fetch(`${HOST_NAME}/api/users`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(newUser),
    });
    if (!response.ok) {
      throw new Error("Failed to add new user");
    }
    const data = await response.json();
    return data;
  }
);

export const updateUserAsync = createAsyncThunk<
  User,
  { userid: number; user: any }
>("users/updateUser", async ({ userid, user }) => {
  try {
    console.log(`Updating user with ID: ${userid}`, user);
    const response = await fetch(`${HOST_NAME}/api/users/${userid}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(user),
    });
    if (!response.ok) {
      const errorDetails = await response.text();
      console.error("Failed to update user:", errorDetails);
      throw new Error(`Failed to update user: ${errorDetails}`);
    }
    const edited = await response.json();
    console.log("Edited user:", edited);
    return edited as User;
  } catch (error) {
    console.error("Error while updating product:", error);
    throw error;
  }
});

export const deleteUser = createAsyncThunk(
  "users/deleteUser",
  async (userid: string, thunkAPI) => {
    try {
      const response = await fetch(`/api/users/${userid}`, {
        method: "DELETE",
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || "Failed to delete user");
      }
      return userid;
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

const usersSlice = createSlice({
  name: "users",
  initialState,
  reducers: {
    addUsers: (state, action: PayloadAction<User[]>) => {
      state.push(...action.payload);
    },
  },
  extraReducers: (builder) => {
    builder.addCase(fetchUsers.fulfilled, (state, action) => {
      return action.payload;
    });
    builder.addCase(updateUserAsync.fulfilled, (state, action) => {
      const updatedUser = action.payload;
      const userIndex = state.findIndex((user) => user._id === updatedUser._id);
      if (userIndex !== -1) {
        state[userIndex] = updatedUser;
      }
    });
    builder.addCase(addUserAsync.fulfilled, (state, action) => {
      state.push(action.payload);
    });
  },
});

export const { addUsers } = usersSlice.actions;
export default usersSlice.reducer;
