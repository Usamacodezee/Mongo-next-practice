import { GET } from "@/app/api/products/route";
import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";

interface Product {
  _id: number;
  name: string;
  description: string;
  category: string;
  price: number;
  discountPercentage: number;
  rating: number;
  stock: number;
  tags: string[];
  brand: string;
  sku: string;
  weight: number;
  warrantyInformation: string;
  shippingInformation: string;
  availabilityStatus: string;
  returnPolicy: string;
  minimumOrderQuantity: number;
  meta: MetaData;
  thumbnail: string;
}

interface MetaData {
  createdAt: Date;
  updatedAt: Date;
}

const HOST_NAME = process.env.HOST_NAME || "http://localhost:3000";

const initialState: Product[] = [];

export const fetchProducts = createAsyncThunk<Product[], void>(
  "products/fetchProducts",
  async () => {
    try {
      const res = await fetch(`${HOST_NAME}/api/products`);
      console.log(res);
      if (!res.ok) {
        throw new Error("Failed to fetch products");
      }
      const jsonData = await res.json();
      return jsonData.data;
    } catch (error) {
      console.error("Error fetching products:", error);
      throw error;
    }
  }
);

export const addProductAsync = createAsyncThunk<Product, Product>(
  "products/addProductAsync",
  async (newProduct) => {
    const response = await fetch(`${HOST_NAME}/api/products`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(newProduct),
    });
    if (!response.ok) {
      throw new Error("Failed to add new product");
    }
    const data = await response.json();
    return data;
  }
);

export const updateProductAsync = createAsyncThunk<
  Product,
  { productid: number; product: any }
>("products/updateProduct", async ({ productid, product }) => {
  try {
    console.log(`Updating product with ID: ${productid}`, product);
    const response = await fetch(`${HOST_NAME}/api/products/${productid}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(product),
    });
    if (!response.ok) {
      const errorDetails = await response.text();
      console.error("Failed to update product:", errorDetails);
      throw new Error(`Failed to update product: ${errorDetails}`);
    }
    const edited = await response.json();
    console.log("Edited product:", edited);
    return edited as Product;
  } catch (error) {
    console.error("Error while updating product:", error);
    throw error;
  }
});

export const deleteProduct = createAsyncThunk(
  "products/deleteProduct",
  async (productId: string, thunkAPI) => {
    try {
      const response = await fetch(`/api/products/${productId}`, {
        method: "DELETE",
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || "Failed to delete product");
      }
      return productId;
    } catch (error: any) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

const productsSlice = createSlice({
  name: "products",
  initialState,
  reducers: {
    addProducts: (state, action: PayloadAction<Product[]>) => {
      state.push(...action.payload);
    },
  },
  extraReducers: (builder) => {
    builder.addCase(fetchProducts.fulfilled, (state, action) => {
      return action.payload;
    });
    builder.addCase(updateProductAsync.fulfilled, (state, action) => {
      const updatedProduct = action.payload;
      const productIndex = state.findIndex(
        (product) => product._id === updatedProduct._id
      );
      if (productIndex !== -1) {
        state[productIndex] = updatedProduct;
      }
    });
    builder.addCase(addProductAsync.fulfilled, (state, action) => {
      state.push(action.payload);
    });
  },
});

export const { addProducts } = productsSlice.actions;
export default productsSlice.reducer;
