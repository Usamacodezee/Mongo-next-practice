import { NextRequest, NextResponse } from 'next/server';
import dbConnect from '@/app/lib/dbConnect';
import Product from '@/app/models/Product';

// Handler for GET requests
export async function GET(req: NextRequest) {
  await dbConnect();
  
  try {
    const products = await Product.find({});
    return NextResponse.json({ success: true, data: products });
  } catch (error) {
    return NextResponse.json({ success: false }, { status: 400 });
  }
}

// Handler for POST requests
export async function POST(req: NextRequest) {
  await dbConnect();
  
  try {
    const data = await req.json();
    const newProduct = new Product(data);
    await newProduct.save();
    return NextResponse.json({ success: true, data: newProduct });
  } catch (error) {
    console.log(error)
    return NextResponse.json({ success: false }, { status: 400 });
  }
}
