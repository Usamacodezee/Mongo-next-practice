import { NextRequest, NextResponse } from 'next/server';
import dbConnect from '@/app/lib/dbConnect';
import User from '@/app/models/User';

// Handler for GET requests
export async function GET(req: NextRequest) {
  await dbConnect();
  
  try {
    const users = await User.find({});
    return NextResponse.json({ success: true, data: users });
  } catch (error) {
    return NextResponse.json({ success: false }, { status: 400 });
  }
}

// Handler for POST requests
export async function POST(req: NextRequest) {
  await dbConnect();
  
  try {
    const data = await req.json();
    const newUser = new User(data);
    await newUser.save();
    return NextResponse.json({ success: true, data: newUser });
  } catch (error) {
    console.log(error)
    return NextResponse.json({ success: false }, { status: 400 });
  }
}
